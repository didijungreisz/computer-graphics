package edu.cg;

import java.util.ArrayList;
import java.util.List;

public class Constraint {
    private double a1 =0;
    private double b1 =0;
    private double c1 =0;
    private double d1 =0;
    private double a2 =0;
    private double b2 =0;
    private double c2 =0;
    private double d2 =0;
    private double B  =0;
    private int i;
    private int length;

  
    public Constraint(double a1, double b1, double c1, double d1,
            double a2, double b2, double c2, double d2,
            double B, int i, int length) {
this.a1 = a1;
this.b1 = b1;
this.c1 = c1;
this.d1 = d1;
this.a2 = a2;
this.b2 = b2;
this.c2 = c2;
this.d2 = d2;
this.B = B;
this.i = i;
this.length = length;
}

public Constraint(int i, int length) {
this.i = i;
this.length = length;
a1 = b1 = c1 = d1 = a2 = b2 = c2 = d2 = B = 0;
}

    public static List<Constraint> calcConstraints(float p, int i, int length) {
        ArrayList<Constraint> constraints = new ArrayList<Constraint>(4);
        constraints.add(Constraint.first(p, i, length));
        constraints.add(Constraint.second(p, i, length));
        constraints.add(Constraint.third(p, i, length));
        constraints.add(Constraint.fourth(p, i, length));
        return constraints;
    }

    private static Constraint fourth(float p, int i, int length) {
    	return new Constraint(3, 1, 0, 0, 0, -1, 0, 0, 0, i, length);
    }

    private static Constraint third(float p, int i, int length) {
    	return new Constraint(3, 2, 1, 0, 0, 0, -1, 0, 0, i, length);

    }

    private static Constraint second(float p, int i, int length) {
    	return new Constraint(1, 1, 1, 1, 0, 0, 0, -1, 0, i, length);

    }

    private static Constraint first(float p, int i, int length) {
    	return new Constraint(0, 0, 0, 1, 0, 0, 0, 0, p, i, length);
     
    }

    public double b() {
        return B;
    }

    public double[] Ai() {
        double[] AI = new double[length * 4];
        double[] components = { a1, b1, c1, d1, a2, b2, c2, d2};
        int index = i * 4;
        for (double d : components) {
        	AI[index] = d;
        	index++;
        	index %= AI.length;
			
		}
   
        return AI;
    }
}