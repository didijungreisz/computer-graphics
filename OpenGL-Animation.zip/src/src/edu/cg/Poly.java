package edu.cg;

public  class Poly {
    private float a;
    private float b;
    private float c;
    private float d;

    public Poly(float a, float b, float c, float d) {
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
    }

    public float p(double t) {
        return (float)((double)d + ((double)c + ((double)b + (double)a * t) * t) * t);
    }

    public float dp(double t) {
        return (float)((double)c + ((double)(2.0f * b) + (double)(3.0f * a) * t) * t);
    }

    public float d2p(double t) {
        return (float)((double)(2.0f * b) + (double)(6.0f * a) * t);
    }
}



