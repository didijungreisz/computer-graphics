
package edu.cg;

import Jama.Matrix;
import edu.cg.CyclicList;
import edu.cg.algebra.Point;
import edu.cg.algebra.Vec;
import java.util.ArrayList;
import java.util.List;

public class RailRoad {
    private double length = 0.0;
    private Spline spline = null;

    private RailRoad() {
    }

    private RailRoad(Spline spline) {
        this.spline = spline;
        this.length = spline.length();
    }

    public static CyclicList<RailRoad> buildRailRoad(CyclicList<Point> points) {
    	
        CyclicList<Poly> xs = calcPolys(points, 1);
        CyclicList<Poly> ys = calcPolys(points, 2);
        CyclicList<Poly> zs = calcPolys(points, 3);
        int size = points.size();
        CyclicList<RailRoad> ans = new CyclicList<RailRoad>();
        for (int i = 0; i < size; ++i) {
            ans.add(new RailRoad(new Spline(xs.get(i), ys.get(i), zs.get(i))));
        }
        return ans;
    }

    private static CyclicList<Poly> calcPolys(CyclicList<Point> points, int selection) {
        int size = points.size();
        List<Constraint> constraints = new ArrayList<>(4 * size);

        for (int i = 0; i < size; i++) {
            Point point = points.get(i);
            float p = 0;
            if (selection == 1)  p = point.x;
            else 
            p =	(selection == 2) ?  point.y:  point.z;
            constraints.addAll(Constraint.calcConstraints(p, i, size));
        }

        float[] polynomialFuncs = axEqualBsolver(constraints);
        CyclicList<Poly> cyclicPolynomials = new CyclicList<Poly>();
        for (int i = 0; i < polynomialFuncs.length; i += 4) {
            int j = i;
            Poly p = new Poly(polynomialFuncs[j++],
                    polynomialFuncs[j++],
                    polynomialFuncs[j++],
                    polynomialFuncs[j++]);
            cyclicPolynomials.add(p);
        }

        return cyclicPolynomials;
    }

    private static float[] axEqualBsolver(List<Constraint> constraints) {
        int size = constraints.size();
        double[][] A = new double[size][0];
        double[] b = new double[size];
        for (int i = 0; i < size; ++i) {
        	 Constraint constraint = constraints.get(i);
             A[i] = constraint.Ai();
             b[i] = constraint.b();
		}
       
        Matrix AMat = new Matrix(A);
        Matrix bMat = new Matrix(b, size);
        Matrix sol = AMat.solve(bMat);
        float[] ans = new float[size];
        for (int i = 0; i < size; ++i) {
        	  ans[i] = (float)sol.get(i, 0);
		}
        
        return ans;
    }

    public LocationOnRailRoad locationOnRailRoad(double t) {
        Point pos = spline.getPosition(t);
        Vec tangent = spline.getTangent(t);
        Vec normal = spline.getNormal(t);
        return new LocationOnRailRoad(pos, tangent, normal);
    }

    public double length() {
        return this.length;
    }

   
}

