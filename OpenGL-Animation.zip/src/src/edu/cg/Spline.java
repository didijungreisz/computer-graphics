package edu.cg;

import edu.cg.Poly;
import edu.cg.algebra.Point;
import edu.cg.algebra.Vec;

public  class Spline {
	        private Poly[] polys = new Poly[3];

	        public Spline(Poly px, Poly py, Poly pz) {
	            this.polys[0] = px;
	            this.polys[1] = py;
	            this.polys[2] = pz;
	        }

	        public double length() {
	            double t = 0.0;
	            double dt = 1.0 / 1024;
	            double[] lengths = new double[1024];
	          
	            for (int i = 0; i < 1024; i++) {
	                Point pos0 = this.getPosition(t);
	                Point pos1 = this.getPosition(t + dt);
	                lengths[i] = pos0.sub(pos1).length();
	                t += dt;
	            }
	            return Spline.sum(lengths);
	        }

	        private static double sum(double[] arr) {
	            return Spline.sum(arr, 0, arr.length - 1);
	        }

	        private static double sum(double[] arr, int lo, int hi) {
	            if (lo >= hi) {
	                return arr[hi];
	            }
	            int mid = (lo + hi) / 2;
	            return Spline.sum(arr, lo, mid) + Spline.sum(arr, mid + 1, hi);
	        }

	        public Point getPosition(double t) {
	            return new Point(polys[0].p(t), polys[1].p(t), polys[2].p(t));
	        }

	        public Vec getTangent(double t) {
	            return new Vec(polys[0].dp(t), polys[1].dp(t), polys[2].dp(t)).normalize();
	        }

	        public Vec getNormal(double t) {
	            Vec dpt = new Vec(polys[0].dp(t), polys[1].dp(t), polys[2].dp(t));
	            Vec d2pt = new Vec(polys[0].d2p(t), polys[1].d2p(t), polys[2].d2p(t));
	            Vec right = dpt.cross(d2pt);
	            return right.cross(dpt).normalize();
	        }
	    }



