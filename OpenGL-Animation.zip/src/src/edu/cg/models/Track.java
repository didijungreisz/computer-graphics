
package edu.cg.models;


import com.jogamp.opengl.GL2;
import com.jogamp.opengl.GLException;
import com.jogamp.opengl.glu.GLU;
import com.jogamp.opengl.util.texture.Texture;
import com.jogamp.opengl.util.texture.TextureIO;
import edu.cg.CyclicList;
import edu.cg.LocationOnRailRoad;
import edu.cg.TrackPoints;
import edu.cg.RailRoad;
import edu.cg.algebra.Point;
import edu.cg.algebra.Vec;
import edu.cg.models.IRenderable;
import edu.cg.models.Locomotive;

import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;

public class Track
implements IRenderable {
    private IRenderable vehicle;
    private CyclicList<Point> trackPoints;
    private Texture texGrass = null;
    private Texture texTrack = null;
    private CyclicList<RailRoad> railRoads = null;
    private double t = 0;
    private int numOfRailRoad = 0;
    double velocity = 0.008;

    public Track(IRenderable vehicle, CyclicList<Point> trackPoints) {
        this.vehicle = vehicle;
        this.trackPoints = trackPoints;
    }

    public Track(IRenderable vehicle) {
        this(vehicle, TrackPoints.track1());
    }

    public Track() {
        this(new Locomotive());
    }

    @Override
    public void init(GL2 gl) {
    	railRoads = RailRoad.buildRailRoad(trackPoints);
       loadTextures(gl);
       vehicle.init(gl);
    }

    private void loadTextures(GL2 gl) {
        File fileGrass = new File("grass.jpg");
        File fileRoad = new File("track.png");
        try {
            texTrack = TextureIO.newTexture(fileRoad, true);
            texGrass = TextureIO.newTexture(fileGrass, false);
        }
        catch (GLException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void render(GL2 gl) {
        this.renderVehicle(gl);
        this.renderField(gl);
        this.renderTrack(gl);
    }

    private void renderVehicle(GL2 gl) {
        gl.glPushMatrix();
        RailRoad railRoad = railRoads.get(numOfRailRoad);
        LocationOnRailRoad location = railRoad.locationOnRailRoad(t);
        Point pos = location.pos;
        Vec tangent = location.tangent.neg();
        Vec normal = location.normal;
        Vec right = location.right().neg();
        gl.glTranslatef(pos.x, pos.y, pos.z);
        double[] mat = new double[]{tangent.x, tangent.y, tangent.z, 0, normal.x, 
        		normal.y, normal.z, 0, right.x, right.y, right.z, 0, 0, 0, 0, 1};
        gl.glMultMatrixd(mat, 0);
        gl.glScaled(0.15, 0.15, 0.15);
        gl.glTranslated(0.0, 0.35, 0.0);
        this.vehicle.render(gl);
        gl.glPopMatrix();
        double length = railRoad.length();
        double dt = velocity / length;
        t += dt;
        if (t > 1) {
            t -= 1;
            numOfRailRoad = (numOfRailRoad + 1) % railRoads.size();
        } else if (t < 0) {
            t += 1;
            numOfRailRoad = (numOfRailRoad - 1) % railRoads.size();
        }
    }

    private void renderField(GL2 gl) {
		gl.glEnable(GL2.GL_TEXTURE_2D);
		gl.glBindTexture(GL2.GL_TEXTURE_2D, texGrass.getTextureObject());
		
		boolean lightningEnabled;
		if((lightningEnabled = gl.glIsEnabled(GL2.GL_LIGHTING)))
			gl.glDisable(GL2.GL_LIGHTING);

		gl.glTexEnvi(GL2.GL_TEXTURE_ENV, GL2.GL_TEXTURE_ENV_MODE, GL2.GL_REPLACE);
		gl.glTexParameteri(GL2.GL_TEXTURE_2D, GL2.GL_TEXTURE_WRAP_T, GL2.GL_REPEAT);
		gl.glTexParameteri(GL2.GL_TEXTURE_2D, GL2.GL_TEXTURE_WRAP_S, GL2.GL_REPEAT);
		gl.glTexParameteri(GL2.GL_TEXTURE_2D, GL2.GL_TEXTURE_MIN_FILTER, GL2.GL_LINEAR);
		gl.glTexParameteri(GL2.GL_TEXTURE_2D, GL2.GL_TEXTURE_MAX_LOD, 1);
		
		gl.glBegin(GL2.GL_QUADS);
		
		gl.glTexCoord2d(0, 0);
		gl.glVertex3d(-1.2, -1.2, -.02);
		gl.glTexCoord2d(4, 0);
		gl.glVertex3d(1.2, -1.2, -.02);
		gl.glTexCoord2d(4, 4);
		gl.glVertex3d(1.2, 1.2, -.02);
		gl.glTexCoord2d(0, 4);
		gl.glVertex3d(-1.2, 1.2, -.02);
		
		gl.glEnd();
		
		if(lightningEnabled)
			gl.glEnable(GL2.GL_LIGHTING);
		
		gl.glDisable(GL2.GL_TEXTURE_2D);
	}

    private void renderTrack(GL2 gl) {
    	gl.glEnable(GL2.GL_TEXTURE_2D);
		gl.glEnable(GL2.GL_BLEND);
		gl.glBlendFunc(GL2.GL_SRC_ALPHA, GL2.GL_ONE_MINUS_SRC_ALPHA);
		gl.glBindTexture(GL2.GL_TEXTURE_2D, texTrack.getTextureObject());
		
		boolean lightningEnabled;
		if((lightningEnabled = gl.glIsEnabled(GL2.GL_LIGHTING)))
			gl.glDisable(GL2.GL_LIGHTING);
		
		gl.glTexEnvi(GL2.GL_TEXTURE_ENV, GL2.GL_TEXTURE_ENV_MODE, GL2.GL_REPLACE);
		gl.glTexParameteri(GL2.GL_TEXTURE_2D, GL2.GL_TEXTURE_WRAP_T, GL2.GL_REPEAT);
		gl.glTexParameteri(GL2.GL_TEXTURE_2D, GL2.GL_TEXTURE_WRAP_S, GL2.GL_REPEAT);
		gl.glTexParameteri(GL2.GL_TEXTURE_2D, GL2.GL_TEXTURE_MIN_FILTER, GL2.GL_LINEAR_MIPMAP_LINEAR);
		gl.glTexParameteri(GL2.GL_TEXTURE_2D, GL2.GL_TEXTURE_MAX_LOD, 2);
        gl.glBegin(GL2.GL_TRIANGLES);
        for (RailRoad railRoad : railRoads) {
            int numOfSubRails = (int)(railRoad.length() / 0.05) + 1;
            double dt = 1 / (double)numOfSubRails;
            double t = 0;
            for (int i = 0; i < numOfSubRails; ++i) {
            	 LocationOnRailRoad l0 = railRoad.locationOnRailRoad(t);
                 LocationOnRailRoad l1 = railRoad.locationOnRailRoad(t + dt);
                 Vec r0 = l0.right();
                 Vec r1 = l1.right();
                 Point p0 = l0.pos.add(r0.mult(0.05f));
                 Point p1 = l1.pos.add(r1.mult(0.05f));
                 Point p2 = l1.pos.add(r1.mult(-0.05f));
                 Point p3 = l0.pos.add(r0.mult(-0.05f));
                 render(gl, p0, p1, p2, p3);
                 t += dt;
			}          
        }
        gl.glEnd();
        if(lightningEnabled)
			gl.glEnable(GL2.GL_LIGHTING);
		
		gl.glDisable(GL2.GL_BLEND);
		gl.glDisable(GL2.GL_TEXTURE_2D);
    }

    private void render(GL2 gl, Point p0, Point p1, Point p2, Point p3) {
        gl.glTexCoord2d(0.0, 0.0);
        gl.glVertex3fv(p0.toGLVertex());
        gl.glTexCoord2d(0.0, 1.0);
        gl.glVertex3fv(p1.toGLVertex());
        gl.glTexCoord2d(1.0, 1.0);
        gl.glVertex3fv(p2.toGLVertex());
        gl.glTexCoord2d(0.0, 0.0);
        gl.glVertex3fv(p0.toGLVertex());
        gl.glTexCoord2d(1.0, 1.0);
        gl.glVertex3fv(p2.toGLVertex());
        gl.glTexCoord2d(0.0, 1.0);
        gl.glVertex3fv(p1.toGLVertex());
        gl.glTexCoord2d(0.0, 0.0);
        gl.glVertex3fv(p0.toGLVertex());
        gl.glTexCoord2d(1.0, 1.0);
        gl.glVertex3fv(p2.toGLVertex());
        gl.glTexCoord2d(1.0, 0.0);
        gl.glVertex3fv(p3.toGLVertex());
        gl.glTexCoord2d(0.0, 0.0);
        gl.glVertex3fv(p0.toGLVertex());
        gl.glTexCoord2d(1.0, 0.0);
        gl.glVertex3fv(p3.toGLVertex());
        gl.glTexCoord2d(1.0, 1.0);
        gl.glVertex3fv(p2.toGLVertex());
    }

    @Override
    public void control(int type, Object params) {
        switch (type) {
        case KeyEvent.VK_UP: {
                this.velocity += 0.005;
                break;
            }
            case KeyEvent.VK_DOWN: {
                this.velocity -= 0.005;
                break;
            }
            case KeyEvent.VK_ENTER: {
                try {
                	Method m = TrackPoints.class.getMethod("track" + params);
    				trackPoints = (CyclicList<Point>)m.invoke(null);
                    railRoads = RailRoad.buildRailRoad(trackPoints);
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
                break;
            }
            case IRenderable.TOGGLE_LIGHT_SPHERES:
    			vehicle.control(type, params);
    			break;
            
            default: 
                System.out.println("Unsupported operation for Track control");
            
        }
    }

    @Override
    public boolean isAnimated() {
        return true;
    }

    @Override
    public void setCamera(GL2 gl) {
    	
        RailRoad railRoad = railRoads.get(numOfRailRoad);
        LocationOnRailRoad location = railRoad.locationOnRailRoad(t);
        Point pos = location.pos;
        Vec tangent = location.tangent;
        Vec normal = location.normal;
        Vec right = location.right();
        Point trans = pos.add(tangent);
        pos = pos.add(tangent.mult(-0.25f)).add(normal.mult(0.25f)).add(right.mult(-0.2f));
        new GLU().gluLookAt(pos.x, pos.y, pos.z, trans.x, trans.y, trans.z, normal.x, normal.y, normal.z);
    }

    @Override
    public void destroy(GL2 gl) {
        texGrass.destroy(gl);
        texTrack.destroy(gl);
        vehicle.destroy(gl);
    }
}

