package edu.cg;

import edu.cg.algebra.Point;
import edu.cg.algebra.Vec;

public  class LocationOnRailRoad {
    public Point pos;
    public Vec tangent;
    public Vec normal;

    public LocationOnRailRoad(Point pos, Vec tangent, Vec normal) {
        this.pos = pos;
        this.tangent = tangent;
        this.normal = normal;
    }

    public Vec right() {
        return this.tangent.cross(this.normal);
    }
}