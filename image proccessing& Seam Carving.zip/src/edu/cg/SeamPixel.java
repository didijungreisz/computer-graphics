package edu.cg;

class SeamPixel {
		public long energy;
		public int predecessorPixel;

		SeamPixel(long energy, int predecessorPixel) {
			this.energy = energy;
			this.predecessorPixel = predecessorPixel;
		}

	}

