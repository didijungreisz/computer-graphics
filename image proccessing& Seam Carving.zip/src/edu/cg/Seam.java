package edu.cg;

public class Seam {

		public long energy;
		public int[] singelSeamPoints;

		Seam(long energy, int[] singelSeamPoints) {
			this.energy = energy;
			this.singelSeamPoints = singelSeamPoints;
		}

		public int[] getSeamPoints() {
			return singelSeamPoints;
		}
	
	}


