package edu.cg;
import java.awt.image.BufferedImage;
import java.util.Arrays;

public class SeamsCarver extends ImageProcessor {

	// MARK: An inner interface for functional programming.
	@FunctionalInterface
	interface ResizeOperation {
		BufferedImage apply();
	}

	// MARK: Fields
	private int numOfSeams;
	private ResizeOperation resizeOp;
	private long[][] energyMatrix;
	private int[][] greyScaleMatrix;
	private Seam[] seamsArray;
	private BufferedImage reducedImage = null;

	// MARK: Constructor
	public SeamsCarver(Logger logger, BufferedImage workingImage, int outWidth, RGBWeights rgbWeights) {
		super(logger, workingImage, rgbWeights, outWidth, workingImage.getHeight());

		numOfSeams = Math.abs(outWidth - inWidth);

		if (inWidth < 2 | inHeight < 2)
			throw new RuntimeException("Can not apply seam carving: workingImage is too small");

		if (numOfSeams > inWidth / 2)
			throw new RuntimeException("Can not apply seam carving: too many seams...");

		// Sets resizeOp with an appropriate method reference
		if (outWidth > inWidth)
			resizeOp = this::increaseImageWidth;
		else if (outWidth < inWidth)
			resizeOp = this::reduceImageWidth;
		else
			resizeOp = this::duplicateWorkingImage;

		seamsArray = new Seam[numOfSeams];
		
		//Initialize seams to remove
		seamsMaker(seamsArray);
		
		// We move the seams we found to the indexes after remove
		for (int i = 0; i < numOfSeams; i++) {
			for (int j = i + 1; j < numOfSeams; j++) {

				// push all seams that came after i and have x position > x position of i
				for (int y = 0; y < inHeight; y++) {
					if (seamsArray[j].getSeamPoints()[y] >= seamsArray[i].getSeamPoints()[y]) {
						seamsArray[j].getSeamPoints()[y]++;
					}
				}
			}
		}

	}
	
	/** Initialize seams by converting to greyscale and
	 *  calculating energy matrix to remove them.
	 * @param seams - array of seams to remove
	 */
	private void seamsMaker(Seam[] seams) {
		int[][] imageMatrix = matrixFromImageConverter(workingImage, inHeight, inWidth);
		int reducedImageWidth = inWidth;
		for (int i = 0; i < numOfSeams; i++) {
			greyScaleMatrix = matrixToGreyScaleConverter(imageMatrix, inHeight, reducedImageWidth);
			energyMatrix = energyMatrix(greyScaleMatrix, inHeight, reducedImageWidth);
			Seam currentSeam = optimalSeamFinder(inHeight, reducedImageWidth);
			seamsArray[i] = currentSeam;
			reducedImageWidth--;
			imageMatrix = seamRemover(imageMatrix, inHeight, reducedImageWidth, currentSeam);
		}
		reducedImage = imageFromMartrixConverter(imageMatrix, inHeight, inWidth - numOfSeams);
	}

	
	/**
	 * Removing seams by deleting the pixels of the seam
	 * 
	 * @param image - the image that we work on
	 * @param height - height of the image
	 * @param width - width of the image
	 * @param seam - the seam that is removed
	 * @return - the image without the seam
	 */
	private int[][] seamRemover(int[][] image, int height, int width, Seam seam) {
		int[] singelSeamPoints = seam.getSeamPoints();
		int[][] convertedImageMatrix = new int[height][width];
		for (int y = 0; y < height; y++) {
			for (int x = 0; x < width; x++) {
				convertedImageMatrix[y][x] = (x >= singelSeamPoints[y])? image[y][x+1] : image[y][x];
			}
		}
		return convertedImageMatrix;
	}

	/**
	 * Find the optimal seam using the energy matrix and the greyscale image
	 * @param height - height of the image
	 * @param width - width of the image
	 * @return
	 */
	private Seam optimalSeamFinder(int height, int width) {
		SeamPixel[][] dynamicMatrix = new SeamPixel[height][width];

		for (int y = 0; y < height; y++) {
			for (int x = 0; x < width; x++) {
				// Initialize the first line
				if (y == 0 ) {
					dynamicMatrix[y][x] = new SeamPixel(energyMatrix[y][x], -1);
				}
				//Initializing the matrix
				else
				{
					
				SeamPixel currentPixel = null;
				long pixelEnergy = energyMatrix[y][x];
				// Left border case
				if (x == 0) 
				{
					//Calculates the new edge
					int cv = Math.abs(greyScaleMatrix[y][x] - greyScaleMatrix[y][x + 1]);
					int cr = Math.abs(greyScaleMatrix[y - 1][x] - greyScaleMatrix[y][x + 1]);
					//Pixels cost
					long verticalPixelCost = dynamicMatrix[y - 1][x].energy + pixelEnergy + cv;
					long rightPixelCost = dynamicMatrix[y - 1][x + 1].energy + pixelEnergy + cr;
					currentPixel = (verticalPixelCost <= rightPixelCost) ? new SeamPixel(verticalPixelCost, x) : new SeamPixel(rightPixelCost, x + 1);
				// Right border case
				} else if (x == width - 1) 
					{
					//Calculates the new edge
					int cv = Math.abs(greyScaleMatrix[y][x - 1] - greyScaleMatrix[y][x]);
					int cl = Math.abs(greyScaleMatrix[y - 1][x] - greyScaleMatrix[y][x - 1]);
					//Pixels cost
					long verticalPixelCost = dynamicMatrix[y - 1][x].energy + pixelEnergy + cv;
					long leftPixelCost = dynamicMatrix[y - 1][x - 1].energy + pixelEnergy + cl;
					currentPixel = (verticalPixelCost <= leftPixelCost) ? new SeamPixel(verticalPixelCost, x) : new SeamPixel(leftPixelCost, x - 1);
				} 
				else 
				{
					//Calculates the new edge
					int cv = Math.abs(greyScaleMatrix[y][x - 1] - greyScaleMatrix[y][x + 1]);
					int cl = Math.abs(greyScaleMatrix[y - 1][x] - greyScaleMatrix[y][x - 1]);
					int cr = Math.abs(greyScaleMatrix[y - 1][x] - greyScaleMatrix[y][x + 1]);
					//Pixels cost
					long leftPixelCost = dynamicMatrix[y - 1][x - 1].energy + cv + cl;
					long verticalPixelCost = dynamicMatrix[y - 1][x].energy + cv;
					long rightPixelCost = dynamicMatrix[y - 1][x + 1].energy + cv + cr;

					if (leftPixelCost <= Math.min(leftPixelCost, Math.min(verticalPixelCost, rightPixelCost))) {
						currentPixel = new SeamPixel(pixelEnergy + leftPixelCost, x - 1);
					} else {
						currentPixel = (verticalPixelCost <= rightPixelCost) ? new SeamPixel(pixelEnergy + verticalPixelCost, x)
								: new SeamPixel(pixelEnergy + rightPixelCost, x + 1);
					}
				}
				dynamicMatrix[y][x] = currentPixel;
				}
			}
		}

		// convert back to seam
		Seam [] seams = new Seam[width];
		for (int x = 0; x < width; x++) {
			seams[x] = seamsGenerator(dynamicMatrix, x, height);
		}

		// Sort seams and return the cheapest one
		Arrays.sort(seams, (seam1, seam2) -> (int) (seam1.energy - seam2.energy));
		return seams[0];
	}
	
	
	/**
	 * Generate the seam from the dynamic matrix
	 * @param dynamicMatrix
	 * @param x
	 * @param height
	 * @return - seam to remove
	 */
	private Seam seamsGenerator(SeamPixel[][] dynamicMatrix, int x, int height) {
		int index =x;
		int[] singelSeamPoints = new int[height];
		int y= height-1;
		while(y>=0) 
		{
		singelSeamPoints[y] = index;
		index = dynamicMatrix[y][index].predecessorPixel;
		y--;
		}	
		return new Seam(dynamicMatrix[height - 1][x].energy, singelSeamPoints);
	}
	
	
	/**
	 * Calculates the energy matrix from the greyscaled matrix
	 * @param greyscaleMatrix
	 * @param height
	 * @param width
	 * @return - the energy matrix from the image
	 */
	private static long[][] energyMatrix(int[][] greyscaleMatrix, int height, int width) {
		long[][] energyMatrix = new long[height][width];
		for (int y = 0; y < height; y++) {
			for (int x = 0; x < width; x++) {
				int weight = greyscaleMatrix[y][x];
				int nextXweight = (x != width - 1) ? (greyscaleMatrix[y][x + 1]) : (greyscaleMatrix[y][x - 1]);
				energyMatrix[y][x] = Math.abs(nextXweight - weight);
			}
		}

		return energyMatrix;
	}
	
	// MARK: Methods
	public BufferedImage resize() {
		logger.log("Prepareing for resizing image...");
		return resizeOp.apply();
	}
	
	private BufferedImage reduceImageWidth() {
		logger.log("Resizing image done!");

		return reducedImage;
	}
	
	private BufferedImage increaseImageWidth() {
		int[][] currentImageMatrix = matrixFromImageConverter(workingImage, inHeight, inWidth);
		//seams contains the number of seams points in each pixel 
		//if none - it will be zero, +1 for each seam that pass through this point
		int[][] seams = new int[inHeight][inWidth];
		for (int i = 0; i < numOfSeams; i++) {
			for (int j = 0; j < seamsArray[0].singelSeamPoints.length; j++) {
				seams[j][seamsArray[i].singelSeamPoints[j]]++;
			}
		}
		//newSizedImageMatrix copy the image to the the sized one
		//if there is 0 it will copy this point 1 time,  k+1 times if it more than 0
		// we need z to move in the x-axis of the newSizedImageMatrix without increasing 
		//the x and moving to incorrect place in the original image matrix
		int[][] newSizedImageMatrix = new int[outHeight][outWidth];
		for (int y = 0; y < outHeight; y++) {
			int z = 0;
			for (int x = 0; x < inWidth; x++) {
				for (int k = 0; k <= seams[y][x]; k++) {
					newSizedImageMatrix[y][z] = currentImageMatrix[y][x];
					z++;
				}
			}
		}
		BufferedImage convertedImage = imageFromMartrixConverter(newSizedImageMatrix, inHeight, inWidth + numOfSeams);
		logger.log("Resizing image done!");
		return convertedImage;
	}

	
	/**
	 * Shows seams on the image
	 * @param seamColorRGB - the color to show
	 * @return - the image with colored seams
	 */
	public BufferedImage showSeams(int seamColorRGB) {
		logger.log("Preparing to show seams...");
		
		for (int y = 0; y < inHeight; y++) {
			for (int x = 0; x < numOfSeams; x++) {
				workingImage.setRGB(seamsArray[x].getSeamPoints()[y], y, seamColorRGB);
			}
		}
		logger.log("Show seams done!");
		return workingImage;
	}
	
	/**
	 * Converts the image matrix to BufferImage
	 * @param image - a matrix that represents the image
	 * @param height - image height
	 * @param width - image width
	 * @return - BufferImage object
	 */
	private BufferedImage imageFromMartrixConverter(int[][] image, int height, int width) {
		BufferedImage convertedImage = newEmptyImage(width, height);
		for (int y = 0; y < height; y++) {
			for (int x = 0; x < width; x++) {
				convertedImage.setRGB(x, y, image[y][x]);
			}
		}
		return convertedImage;
	}
	
	/**
	 * Converts BufferImage to matrix
	 * @param image - BufferImage object
	 * @param height
	 * @param width
	 * @return
	 */
	private  int[][] matrixFromImageConverter(BufferedImage image, int height, int width) {
		int[][] matrix = new int[height][width];
		forEach((y, x) -> {
			matrix[y][x] = image.getRGB(x, y);
		});
		return matrix;
	}
	
	/**
	 * @param image - image represented by matrix
	 * @param height - image height
	 * @param width - image width
	 * @return - a matrix that represents greyscale image values
	 */
	private  int[][] matrixToGreyScaleConverter(int[][] image, int height, int width) {
		int[][] matrix = new int[height][width];
		for (int y = 0; y < height; y++) {
			for (int x = 0; x < width; x++) {
				matrix[y][x] = image[y][x] & 255;
			}
		}
		return matrix;
	}
	
}