	/**
	 * Shows seams on the image
	 * @param seamColorRGB - the color to show
	 * @return - the image with colored seams
	 */
	public BufferedImage showSeams(int seamColorRGB) {
		logger.log("Preparing to show seams...");
		
		for (int y = 0; y < inHeight; y++) {
			for (int x = 0; x < numOfSeams; x++) {
				workingImage.setRGB(seamsArray[x].getSeamPoints()[y], y, seamColorRGB);
			}
		}
		logger.log("Show seams done!");
		return workingImage;
	}