package edu.cg;

import java.awt.Color;
import java.awt.image.BufferedImage;

public class ImageProcessor extends FunctioalForEachLoops {

	// MARK: Fields
	public final Logger logger;
	public final BufferedImage workingImage;
	public final RGBWeights rgbWeights;
	public final int inWidth;
	public final int inHeight;
	public final int workingImageType;
	public final int outWidth;
	public final int outHeight;

	// MARK: Constructors
	public ImageProcessor(Logger logger, BufferedImage workingImage, RGBWeights rgbWeights, int outWidth,
			int outHeight) {
		super(); // Initializing for each loops...

		this.logger = logger;
		this.workingImage = workingImage;
		this.rgbWeights = rgbWeights;
		inWidth = workingImage.getWidth();
		inHeight = workingImage.getHeight();
		workingImageType = workingImage.getType();
		this.outWidth = outWidth;
		this.outHeight = outHeight;
		setForEachInputParameters();
	}

	public ImageProcessor(Logger logger, BufferedImage workingImage, RGBWeights rgbWeights) {
		this(logger, workingImage, rgbWeights, workingImage.getWidth(), workingImage.getHeight());
	}

	// MARK: Change picture hue - example
	public BufferedImage changeHue() {
		logger.log("Prepareing for hue changing...");

		int r = rgbWeights.redWeight;
		int g = rgbWeights.greenWeight;
		int b = rgbWeights.blueWeight;
		int max = rgbWeights.maxWeight;

		BufferedImage ans = newEmptyInputSizedImage();

		forEach((y, x) -> {
			Color c = new Color(workingImage.getRGB(x, y));
			int red = r * c.getRed() / max;
			int green = g * c.getGreen() / max;
			int blue = b * c.getBlue() / max;
			Color color = new Color(red, green, blue);
			ans.setRGB(x, y, color.getRGB());
		});

		logger.log("Changing hue done!");

		return ans;
	}

	/**
	 * Change image to greyscale colors.
	 * @return greyscaled image.
	 */
	public BufferedImage greyscale() 
	{
		logger.log("Prepareing for greyscale changing...");

		int redWeight = rgbWeights.redWeight;
		int greenWeight = rgbWeights.greenWeight;
		int blueWeight = rgbWeights.blueWeight;
		BufferedImage convertedImage = newEmptyInputSizedImage();

		forEach((y, x) -> 
		{
			Color pixelColor = new Color(workingImage.getRGB(x, y));
			int grey = (pixelColor.getRed() * redWeight + pixelColor.getGreen() * greenWeight + pixelColor.getBlue() * blueWeight) 
						/ (redWeight + greenWeight + blueWeight);
			Color newColor = new Color(grey, grey, grey);
			convertedImage.setRGB(x, y, newColor.getRGB());
		});

		logger.log("Changing to greyscales done!");

		return convertedImage;

	}

	/**
	 * Calculate the gradient mangnitude on image.
	 * @return and image with gradient magnitude at each pixel
	 */
	public BufferedImage gradientMagnitude() 
	{
		logger.log("Preparing for gradient magnitude...");
		BufferedImage convertedImage = newEmptyInputSizedImage();
		BufferedImage greyScaledImage = greyscale();
		
		forEach((y,x) -> 
		{
			//Calculates the derivatives
		int dx = derivativeX(x,y, greyScaledImage);
		int dy = derivativeY(x,y, greyScaledImage);
		
		int gradientMagnitude = (int) Math.sqrt((Math.pow(dx, 2) + Math.pow(dy, 2)) / 2);
		Color newColor = new Color(gradientMagnitude, gradientMagnitude, gradientMagnitude);
		convertedImage.setRGB(x, y, newColor.getRGB());
		});
		
		logger.log("Changing to gradient magnitude mode done!");
		return convertedImage;
	}
	
	/**
	 * Calculates the derivative of X
	 * @param x - x coordinate
	 * @param y - y coordinate
	 * @param greyScaledImage - the image converted to greyscaled colors.
	 * @return - the derivative of x
	 */
	private int derivativeX(Integer x, Integer y, BufferedImage greyScaledImage) 
	{
		int nextHorizontalPixelWeight;
		int weightOfGreyScaled = greyScaledImage.getRGB(x, y) & 255;
		if (x == inWidth - 1)
		{
			nextHorizontalPixelWeight = greyScaledImage.getRGB(x - 1, y) & 255;
		}
		else
		{
			nextHorizontalPixelWeight = greyScaledImage.getRGB(x + 1, y) & 255;
		}
			
		return nextHorizontalPixelWeight - weightOfGreyScaled;
	}
	
	/**
	 * Calculates the derivative of Y
	 * @param x - x coordinate
	 * @param y - y coordinate
	 * @param greyScaledImage - the image converted to greyscaled colors.
	 * @return - the derivative of y
	 */
	
	private int derivativeY(Integer x, Integer y, BufferedImage greyScaledImage) 
	{
		int nextVerticalPixelWeight;
		int weightOfGreyScaled = greyScaledImage.getRGB(x, y) & 255;
		if (y == inHeight - 1)
		{
			nextVerticalPixelWeight = greyScaledImage.getRGB(x , y - 1) & 255;
		}
		else
		{
			nextVerticalPixelWeight = greyScaledImage.getRGB(x , y + 1) & 255;
		}
			
		return nextVerticalPixelWeight - weightOfGreyScaled;
	}
	

	/**
	 * Resize the working image with Nearest Neighbor algorithm.
	 * @return - Resized image.
	 */
	public BufferedImage nearestNeighbor() {
	 logger.log("Preparing for  resizing by Nearest Neighbor...");
     BufferedImage convertedImage = newEmptyOutputSizedImage();
	  
     //Resize retion
     int heightRatio = (int) ((inHeight<<16)/outHeight) +1;
     int widthRatio = (int) ((inWidth<<16)/outWidth) +1;

     setForEachOutputParameters();
     forEach((y, x) -> 
     {
         int nearestY = ((y * heightRatio)>> 16);
         int nearestX = ((x * widthRatio)>> 16);
         convertedImage.setRGB(x, y, workingImage.getRGB(nearestX, nearestY));
     });

     logger.log("Resizing by Nearest Neighbor done!");
     return convertedImage;
	}

	/**
	 * Resize the working image with Bilinear algorithm.
	 * @return - Resized image.
	 */
public BufferedImage bilinear() 
{
	logger.log("Preparing for bilinear...");
	BufferedImage convertedImage = newEmptyOutputSizedImage();
	
	//Resize ratio
	double widthRatio = inWidth / (double) outWidth;
	double heightRatio = inHeight / (double) outHeight;

	setForEachOutputParameters();
	forEach((y, x) -> {
		
		//Directions of 4 pixel around the point
		int left = (int) (x * widthRatio);
		int right = (left + 1 > inWidth - 1 ? inWidth -1 : left + 1); 
		int up = (int) (y * heightRatio);
		int down =  (up + 1 > inHeight - 1 ? inHeight -1  : up + 1);

		//Calculates distance for x and y
		double widthDistance = (double) right - (x * widthRatio);
		double heightDistance = (double) down - (y * heightRatio);
		
		//Coordinates of 4 pixels around the point
		Color pixelLeftUp = new Color(workingImage.getRGB(left, up));
		Color pixelRightUp = new Color(workingImage.getRGB(right, up));
		Color pixelLeftDown = new Color(workingImage.getRGB(left, down));
		Color pixelRightDown = new Color(workingImage.getRGB(right, down));
		
		//Calculates the linear interpolation for upper and lower bound
		Color upperBound = linearInterpolation(pixelLeftDown, pixelRightDown, widthDistance);
		Color lowerBound = linearInterpolation(pixelLeftUp, pixelRightUp, widthDistance);
				

		convertedImage.setRGB(x, y, linearInterpolation(lowerBound, upperBound, heightDistance).getRGB());
	});

	logger.log("Bilinear done!");
	return convertedImage;
}

/**
 * Calculates the linear interpolation between two points
 * @param firstPixel
 * @param secondPixel
 * @param distance
 * @return - The linear interpolation
 */
private static Color linearInterpolation(Color firstPixel, Color secondPixel, double distance) 
{
	int [] firstColor = {firstPixel.getRed(),firstPixel.getGreen(),firstPixel.getBlue()};
	int [] secondColor = {secondPixel.getRed(),secondPixel.getGreen(),secondPixel.getBlue()};
	int [] newColor = new int[3];
	for ( int i = 0; i < 3; i++)
	{
		newColor[i]= (int) ((1 - distance) * secondColor[i] + distance * firstColor[i]);
	}
	
	return new Color(newColor[0], newColor[1], newColor[2]);
}

	// MARK: Utilities
	public final void setForEachInputParameters() {
		setForEachParameters(inWidth, inHeight);
	}

	public final void setForEachOutputParameters() {
		setForEachParameters(outWidth, outHeight);
	}

	public final BufferedImage newEmptyInputSizedImage() {
		return newEmptyImage(inWidth, inHeight);
	}

	public final BufferedImage newEmptyOutputSizedImage() {
		return newEmptyImage(outWidth, outHeight);
	}

	public final BufferedImage newEmptyImage(int width, int height) {
		return new BufferedImage(width, height, workingImageType);
	}

	public final BufferedImage duplicateWorkingImage() {
		BufferedImage output = newEmptyInputSizedImage();

		forEach((y, x) -> output.setRGB(x, y, workingImage.getRGB(x, y)));

		return output;
	}
}
