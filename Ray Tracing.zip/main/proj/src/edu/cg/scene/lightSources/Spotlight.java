package edu.cg.scene.lightSources;

import edu.cg.algebra.Point;
import edu.cg.algebra.Ray;
import edu.cg.algebra.Vec;
import edu.cg.scene.objects.Surface;

public class Spotlight extends PointLight {
	private Vec direction;
	private double angle = 0.866; //cosine value ~ 30 degrees
	
	public Spotlight initDirection(Vec direction) {
		this.direction = direction;
		return this;
	}
	
	public Spotlight initAngle(double angle) {
		this.angle = angle;
		return this;
	}
	
	@Override
	public String toString() {
		String endl = System.lineSeparator();
		return "Spotlight: " + endl +
				description() + 
				"Direction: " + direction + endl +
				"Angle: " + angle + endl;
	}
	
	@Override
	public Spotlight initPosition(Point position) {
		return (Spotlight)super.initPosition(position);
	}
	
	@Override
	public Spotlight initIntensity(Vec intensity) {
		return (Spotlight)super.initIntensity(intensity);
	}
	
	@Override
	public Spotlight initDecayFactors(double q, double l, double c) {
		return (Spotlight)super.initDecayFactors(q, l, c);
	}
	
    @Override
    public boolean isBlockedByObj(Surface surface, Ray lightRay) {
    	boolean isBlocked = true;
        if (lightRay.direction().neg().dot(direction.normalize()) >= angle) 
        {
            isBlocked = super.isBlockedByObj(surface, lightRay);
        }
        return isBlocked;
    }

    @Override
    public Vec pointIntensity(Point hittingPoint, Ray lightRay) {
        Vec D = direction.normalize().neg();
        Vec L = lightRay.direction();
        return super.pointIntensity(hittingPoint, lightRay).mult(D.dot(L));
    }}
