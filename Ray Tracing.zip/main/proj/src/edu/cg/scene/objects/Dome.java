package edu.cg.scene.objects;

import edu.cg.algebra.Hit;
import edu.cg.algebra.Ops;
import edu.cg.algebra.Point;
import edu.cg.algebra.Ray;
import edu.cg.algebra.Vec;

public class Dome extends Shape {
	private Sphere sphere;
	private Plain plain;

	public Dome() {
		sphere = new Sphere().initCenter(new Point(0, -0.5, -6));
		plain = new Plain(new Vec(-1, 0, -1), new Point(0, -0.5, -6));
	}

	@Override
	public String toString() {
		String endl = System.lineSeparator();
		return "Dome:" + endl + sphere + plain + endl;
	}

	//change names
	@Override
	public Hit intersect(Ray ray) {
		Hit hit = sphere.intersect(ray);
		if (hit == null) {
			return null;
		}		
		Point hittingPoint = ray.getHittingPoint(hit);
		
		//P0 * N + d
		Vec abc = new Vec(plain.getA(), plain.getB(), plain.getC());
		double hittingPointSub = abc.dot(hittingPoint.toVec()) + plain.getD();
		double raySourceSub = abc.dot(ray.source().toVec()) + plain.getD();
		if (hit.isWithinTheSurface()) {
			if (raySourceSub > Ops.epsilon) {
				if (hittingPointSub <= 0.0) {
					hit = plain.intersect(ray);
					return hit != null ? hit.setWithin() : null;
				}
				return hit;
			}
			return (hittingPointSub > 0) ? plain.intersect(ray) : null;
		}

		else {
			if (hittingPointSub <= 0) 
			{	
			hit = plain.intersect(ray);
			if (hit == null) {
				return null;
			}
			hittingPoint = ray.getHittingPoint(hit);
			return hittingPoint.distSqr(sphere.getCenter()) - sphere.getRadius() * sphere.getRadius() < 0 ? hit: null;
			}
			return hit;
		}
	}

}
