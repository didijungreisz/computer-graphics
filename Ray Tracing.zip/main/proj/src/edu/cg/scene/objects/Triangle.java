package edu.cg.scene.objects;

import edu.cg.algebra.*;

public class Triangle extends Shape {
	private Point p1, p2, p3;
	private transient Plain trianglesPlain = null;

	public Triangle() {
		p1 = p2 = p3 = null;
	}

	public Triangle(Point p1, Point p2, Point p3) {
		this.p1 = p1;
		this.p2 = p2;
		this.p3 = p3;
	}

	@Override
	public String toString() {
		String endl = System.lineSeparator();
		return "Triangle:" + endl + "p1: " + p1 + endl + "p2: " + p2 + endl + "p3: " + p3 + endl;
	}

	private Plain getTrianglesPlain() {
		if (trianglesPlain == null) {
			synchronized (this) {
				Vec v1 = p2.sub(p1);
				Vec v2 = p2.sub(p3);
				Vec normal = v1.cross(v2).normalize();
				trianglesPlain = new Plain(normal, p2);
			}
		}
		return trianglesPlain;
	}

	@Override
	public Hit intersect(Ray ray) {
		Hit plainHit = getTrianglesPlain().intersect(ray);
		if (plainHit != null) {
			Point intersectionPoint = ray.add(plainHit.t());
			Vec u = p2.sub(p1);
			Vec v = p3.sub(p1);
			Vec w = intersectionPoint.sub(p1);
			double k = Math.pow(u.dot(v), 2) - (u.dot(u) * v.dot(v));
			double s = ((u.dot(v) * w.dot(v)) - (v.dot(v) * w.dot(u))) / k;
			double t = ((u.dot(v) * w.dot(u)) - (u.dot(u) * w.dot(v))) / k;
			if (s > Ops.epsilon && t > Ops.epsilon && s + t <= 1 + Ops.epsilon) {
				return plainHit;
			}
		}
		return null;
	}
}